# WordPress MySQL database migration
#
# Generated: Wednesday 10. February 2016 11:04 UTC
# Hostname: 10.169.0.73
# Database: `cioswebs_vfgr`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `hkgj_commentmeta`
#

DROP TABLE IF EXISTS `hkgj_commentmeta`;


#
# Table structure of table `hkgj_commentmeta`
#

CREATE TABLE `hkgj_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `hkgj_commentmeta`
#

#
# End of data contents of table `hkgj_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `hkgj_comments`
#

DROP TABLE IF EXISTS `hkgj_comments`;


#
# Table structure of table `hkgj_comments`
#

CREATE TABLE `hkgj_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `hkgj_comments`
#
INSERT INTO `hkgj_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2010-06-18 20:51:35', '2010-06-18 20:51:35', 'Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `hkgj_comments`
# --------------------------------------------------------



#
# Delete any existing table `hkgj_links`
#

DROP TABLE IF EXISTS `hkgj_links`;


#
# Table structure of table `hkgj_links`
#

CREATE TABLE `hkgj_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


#
# Data contents of table `hkgj_links`
#
INSERT INTO `hkgj_links` ( `link_id`, `link_url`, `link_name`, `link_image`, `link_target`, `link_description`, `link_visible`, `link_owner`, `link_rating`, `link_updated`, `link_rel`, `link_notes`, `link_rss`) VALUES
(1, 'http://codex.wordpress.org/', 'Documentation', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', ''),
(2, 'http://wordpress.org/development/', 'WordPress Blog', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', 'http://wordpress.org/development/feed/'),
(3, 'http://wordpress.org/extend/ideas/', 'Suggest Ideas', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', ''),
(4, 'http://wordpress.org/support/', 'Support Forum', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', ''),
(5, 'http://wordpress.org/extend/plugins/', 'Plugins', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', ''),
(6, 'http://wordpress.org/extend/themes/', 'Themes', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', ''),
(7, 'http://planet.wordpress.org/', 'WordPress Planet', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ;

#
# End of data contents of table `hkgj_links`
# --------------------------------------------------------



#
# Delete any existing table `hkgj_options`
#

DROP TABLE IF EXISTS `hkgj_options`;


#
# Table structure of table `hkgj_options`
#

CREATE TABLE `hkgj_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) DEFAULT NULL,
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=229 DEFAULT CHARSET=utf8;


#
# Data contents of table `hkgj_options`
#
INSERT INTO `hkgj_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://192.168.33.10/', 'yes'),
(2, 'blogname', 'My blog', 'yes'),
(3, 'blogdescription', 'Just another WordPress site', 'yes'),
(4, 'users_can_register', '0', 'yes'),
(5, 'admin_email', 'admin@cios.website', 'yes'),
(6, 'start_of_week', '1', 'yes'),
(7, 'use_balanceTags', '0', 'yes'),
(8, 'use_smilies', '1', 'yes'),
(9, 'require_name_email', '1', 'yes'),
(10, 'comments_notify', '1', 'yes'),
(11, 'posts_per_rss', '10', 'yes'),
(12, 'rss_use_excerpt', '0', 'yes'),
(13, 'mailserver_url', 'mail.example.com', 'yes'),
(14, 'mailserver_login', 'login@example.com', 'yes'),
(15, 'mailserver_pass', 'password', 'yes'),
(16, 'mailserver_port', '110', 'yes'),
(17, 'default_category', '1', 'yes'),
(18, 'default_comment_status', 'open', 'yes'),
(19, 'default_ping_status', 'open', 'yes'),
(20, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(29, 'comment_moderation', '0', 'yes'),
(30, 'moderation_notify', '1', 'yes'),
(31, 'permalink_structure', '/%category%/%postname%/', 'yes'),
(33, 'hack_file', '0', 'yes'),
(34, 'blog_charset', 'UTF-8', 'yes'),
(35, 'moderation_keys', '', 'no'),
(36, 'active_plugins', 'a:3:{i:0;s:27:"cornerstone/cornerstone.php";i:1;s:45:"limit-login-attempts/limit-login-attempts.php";i:2;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(37, 'home', 'http://192.168.33.10/', 'yes'),
(38, 'category_base', '', 'yes'),
(39, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(41, 'comment_max_links', '2', 'yes'),
(42, 'gmt_offset', '0', 'yes'),
(43, 'default_email_category', '1', 'yes'),
(44, 'recently_edited', '', 'no'),
(45, 'template', 'x', 'yes'),
(46, 'stylesheet', 'x', 'yes'),
(47, 'comment_whitelist', '1', 'yes'),
(48, 'blacklist_keys', '', 'no'),
(49, 'comment_registration', '0', 'yes'),
(51, 'html_type', 'text/html', 'yes'),
(52, 'use_trackback', '0', 'yes'),
(53, 'default_role', 'subscriber', 'yes'),
(54, 'db_version', '35700', 'yes'),
(55, 'uploads_use_yearmonth_folders', '1', 'yes'),
(56, 'upload_path', '/var/sites/c/cios.website/public_html/wp-content/uploads', 'yes'),
(57, 'blog_public', '1', 'yes'),
(58, 'default_link_category', '2', 'yes'),
(59, 'show_on_front', 'posts', 'yes'),
(60, 'tag_base', '', 'yes'),
(61, 'show_avatars', '1', 'yes'),
(62, 'avatar_rating', 'G', 'yes'),
(63, 'upload_url_path', '', 'yes'),
(64, 'thumbnail_size_w', '150', 'yes'),
(65, 'thumbnail_size_h', '150', 'yes'),
(66, 'thumbnail_crop', '1', 'yes'),
(67, 'medium_size_w', '300', 'yes'),
(68, 'medium_size_h', '300', 'yes'),
(69, 'avatar_default', 'mystery', 'yes'),
(72, 'large_size_w', '1024', 'yes'),
(73, 'large_size_h', '1024', 'yes'),
(74, 'image_default_link_type', 'file', 'yes'),
(75, 'image_default_size', '', 'yes'),
(76, 'image_default_align', '', 'yes'),
(77, 'close_comments_for_old_posts', '0', 'yes'),
(78, 'close_comments_days_old', '14', 'yes'),
(79, 'thread_comments', '1', 'yes'),
(80, 'thread_comments_depth', '5', 'yes'),
(81, 'page_comments', '0', 'yes'),
(82, 'comments_per_page', '50', 'yes'),
(83, 'default_comments_page', 'newest', 'yes'),
(84, 'comment_order', 'asc', 'yes'),
(85, 'sticky_posts', 'a:0:{}', 'yes'),
(86, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(87, 'widget_text', 'a:0:{}', 'yes'),
(88, 'widget_rss', 'a:0:{}', 'yes'),
(89, 'timezone_string', '', 'yes'),
(91, 'embed_size_w', '', 'yes'),
(92, 'embed_size_h', '600', 'yes'),
(93, 'page_for_posts', '0', 'yes'),
(94, 'page_on_front', '0', 'yes'),
(95, 'hkgj_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:11:{s:19:"wp_inactive_widgets";a:0:{}s:12:"sidebar-main";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:8:"header-1";a:0:{}s:8:"header-2";a:0:{}s:8:"header-3";a:0:{}s:8:"header-4";a:0:{}s:8:"footer-1";a:0:{}s:8:"footer-2";N;s:8:"footer-3";N;s:8:"footer-4";N;s:13:"array_version";i:3;}', 'yes'),
(102, 'ftp_credentials', 'a:3:{s:8:"hostname";s:9:"localhost";s:8:"username";N;s:15:"connection_type";s:3:"ftp";}', 'yes'),
(103, 'uninstall_plugins', 'a:0:{}', 'no'),
(104, 'default_post_format', '0', 'yes'),
(105, 'link_manager_enabled', '1', 'yes'),
(106, 'initial_db_version', '15260', 'yes'),
(108, 'db_upgraded', '', 'yes'),
(109, 'WPLANG', 'en', 'yes'),
(110, 'cron', 'a:5:{i:1455106721;a:1:{s:26:"upgrader_scheduled_cleanup";a:1:{s:32:"adcb9b75260590ff6058773ddcb9ddd6";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:4;}}}}i:1455140006;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1455185658;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1455188543;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(143, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `hkgj_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(144, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(145, 'widget_links', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(146, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(147, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(148, 'finished_splitting_shared_terms', '1', 'yes'),
(149, 'site_icon', '0', 'yes'),
(150, 'medium_large_size_w', '768', 'yes'),
(151, 'medium_large_size_h', '0', 'yes'),
(155, 'can_compress_scripts', '1', 'yes'),
(162, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1455099554;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:19:"primary-widget-area";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:21:"secondary-widget-area";a:0:{}s:24:"first-footer-widget-area";a:0:{}s:25:"second-footer-widget-area";a:0:{}s:24:"third-footer-widget-area";a:0:{}s:25:"fourth-footer-widget-area";a:0:{}}}}', 'yes'),
(163, 'current_theme', 'X', 'yes'),
(164, 'theme_mods_x', 'a:1:{i:0;b:0;}', 'yes'),
(165, 'theme_switched', '', 'yes'),
(167, 'x_extension_list', 'a:20:{i:0;a:9:{s:4:"slug";s:11:"convertplug";s:6:"plugin";s:27:"convertplug/convertplug.php";s:11:"new_version";s:5:"1.1.1";s:7:"package";N;s:5:"title";s:11:"ConvertPlug";s:11:"description";s:146:"Transform your website into a lead generation powerhouse! Fuel engagement with your visitors, get more subscribers, and increase conversion rates.";s:8:"logo_url";s:62:"//theme.co/media/x_extensions/200-200-no-title-convertplug.png";s:6:"author";s:16:"Brainstorm Force";s:8:"demo_url";s:46:"http://theme.co/x/demo/extensions/convertplug/";}i:1;a:9:{s:4:"slug";s:14:"envira-gallery";s:6:"plugin";s:33:"envira-gallery/envira-gallery.php";s:11:"new_version";s:7:"1.4.1.3";s:7:"package";N;s:5:"title";s:14:"Envira Gallery";s:11:"description";s:135:"Envira Gallery is a fantastic responsive WordPress gallery plugin. Create beautiful photo and video galleries for your site in minutes.";s:8:"logo_url";s:65:"//theme.co/media/x_extensions/200-200-no-title-envira-gallery.png";s:6:"author";s:14:"Thomas Griffin";s:8:"demo_url";s:49:"http://theme.co/x/demo/extensions/envira-gallery/";}i:2;a:9:{s:4:"slug";s:14:"essential-grid";s:6:"plugin";s:33:"essential-grid/essential-grid.php";s:11:"new_version";s:7:"2.0.9.1";s:7:"package";N;s:5:"title";s:14:"Essential Grid";s:11:"description";s:151:"Essential Grid is an all-purpose grid building solution for WordPress that allows you to display various content formats in a highly customizable grid.";s:8:"logo_url";s:65:"//theme.co/media/x_extensions/200-200-no-title-essential-grid.png";s:6:"author";s:10:"ThemePunch";s:8:"demo_url";s:49:"http://theme.co/x/demo/extensions/essential-grid/";}i:3;a:9:{s:4:"slug";s:11:"js_composer";s:6:"plugin";s:27:"js_composer/js_composer.php";s:11:"new_version";s:5:"4.9.2";s:7:"package";N;s:5:"title";s:15:"Visual Composer";s:11:"description";s:141:"We recommend using Cornerstone for page building in X as it is built and managed by Themeco; however, Visual Composer is an alternate choice.";s:8:"logo_url";s:66:"//theme.co/media/x_extensions/200-200-no-title-visual-composer.png";s:6:"author";s:8:"WPBakery";s:8:"demo_url";s:50:"http://theme.co/x/demo/extensions/visual-composer/";}i:4;a:9:{s:4:"slug";s:11:"layerslider";s:6:"plugin";s:27:"LayerSlider/layerslider.php";s:11:"new_version";s:5:"5.6.2";s:7:"package";N;s:5:"title";s:11:"LayerSlider";s:11:"description";s:135:"LayerSlider is the most advanced responsive WordPress slider plugin with the famous Parallax Effect and over 200 2D and 3D transitions.";s:8:"logo_url";s:62:"//theme.co/media/x_extensions/200-200-no-title-layerslider.png";s:6:"author";s:14:"Kreatura Media";s:8:"demo_url";s:46:"http://theme.co/x/demo/extensions/layerslider/";}i:5;a:9:{s:4:"slug";s:9:"revslider";s:6:"plugin";s:23:"revslider/revslider.php";s:11:"new_version";s:5:"5.1.6";s:7:"package";N;s:5:"title";s:17:"Slider Revolution";s:11:"description";s:103:"Create responsive sliders with must-see-effects, all while maintaining your search engine optimization.";s:8:"logo_url";s:68:"//theme.co/media/x_extensions/200-200-no-title-slider-revolution.png";s:6:"author";s:10:"ThemePunch";s:8:"demo_url";s:52:"http://theme.co/x/demo/extensions/slider-revolution/";}i:6;a:9:{s:4:"slug";s:9:"soliloquy";s:6:"plugin";s:23:"soliloquy/soliloquy.php";s:11:"new_version";s:5:"2.4.3";s:7:"package";N;s:5:"title";s:9:"Soliloquy";s:11:"description";s:151:"Soliloquy is a responsive WordPress slider plugin that makes building sliders in WordPress a task that you will want to experience over and over again.";s:8:"logo_url";s:60:"//theme.co/media/x_extensions/200-200-no-title-soliloquy.png";s:6:"author";s:14:"Thomas Griffin";s:8:"demo_url";s:44:"http://theme.co/x/demo/extensions/soliloquy/";}i:7;a:9:{s:4:"slug";s:14:"x-content-dock";s:6:"plugin";s:33:"x-content-dock/x-content-dock.php";s:11:"new_version";s:5:"1.0.0";s:7:"package";N;s:5:"title";s:12:"Content Dock";s:11:"description";s:152:"An incredibly simple and effective tool that allows you to place content or marketing offers in front of your users in an elegant, non-intrusive manner.";s:8:"logo_url";s:63:"//theme.co/media/x_extensions/200-200-no-title-content-dock.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:47:"http://theme.co/x/demo/extensions/content-dock/";}i:8;a:9:{s:4:"slug";s:12:"x-custom-404";s:6:"plugin";s:29:"x-custom-404/x-custom-404.php";s:11:"new_version";s:5:"1.1.0";s:7:"package";N;s:5:"title";s:10:"Custom 404";s:11:"description";s:170:"Redirect all of your site\'s 404 errors to a custom page that you have complete control over. Easily create any layout you want using page templates, shortcodes, and more!";s:8:"logo_url";s:61:"//theme.co/media/x_extensions/200-200-no-title-custom-404.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:45:"http://theme.co/x/demo/extensions/custom-404/";}i:9;a:9:{s:4:"slug";s:17:"x-disqus-comments";s:6:"plugin";s:39:"x-disqus-comments/x-disqus-comments.php";s:11:"new_version";s:5:"1.0.0";s:7:"package";N;s:5:"title";s:15:"Disqus Comments";s:11:"description";s:146:"Take advantage of powerful and unique features by integrating Disqus comments on your website instead of the standard WordPress commenting system.";s:8:"logo_url";s:66:"//theme.co/media/x_extensions/200-200-no-title-disqus-comments.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:50:"http://theme.co/x/demo/extensions/disqus-comments/";}i:10;a:9:{s:4:"slug";s:17:"x-email-mailchimp";s:6:"plugin";s:39:"x-email-mailchimp/x-email-mailchimp.php";s:11:"new_version";s:5:"1.1.1";s:7:"package";N;s:5:"title";s:23:"Email Forms (MailChimp)";s:11:"description";s:171:"Creating custom opt-in forms has never been this easy...or fun! Carefully craft every detail of your forms using this plugin and subscribe users to a MailChimp email list.";s:8:"logo_url";s:66:"//theme.co/media/x_extensions/200-200-no-title-email-mailchimp.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:56:"http://theme.co/x/demo/extensions/email-forms-mailchimp/";}i:11;a:9:{s:4:"slug";s:19:"x-facebook-comments";s:6:"plugin";s:43:"x-facebook-comments/x-facebook-comments.php";s:11:"new_version";s:5:"1.0.1";s:7:"package";N;s:5:"title";s:17:"Facebook Comments";s:11:"description";s:148:"Take advantage of powerful and unique features by integrating Facebook comments on your website instead of the standard WordPress commenting system.";s:8:"logo_url";s:68:"//theme.co/media/x_extensions/200-200-no-title-facebook-comments.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:52:"http://theme.co/x/demo/extensions/facebook-comments/";}i:12;a:9:{s:4:"slug";s:18:"x-google-analytics";s:6:"plugin";s:41:"x-google-analytics/x-google-analytics.php";s:11:"new_version";s:5:"1.0.0";s:7:"package";N;s:5:"title";s:16:"Google Analytics";s:11:"description";s:142:"Simply drop in your Google Analytics code snippet, select where you\'d like it to be output, and you\'re good to go! Google Analytics made easy.";s:8:"logo_url";s:67:"//theme.co/media/x_extensions/200-200-no-title-google-analytics.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:51:"http://theme.co/x/demo/extensions/google-analytics/";}i:13;a:9:{s:4:"slug";s:19:"x-olark-integration";s:6:"plugin";s:43:"x-olark-integration/x-olark-integration.php";s:11:"new_version";s:5:"1.0.0";s:7:"package";N;s:5:"title";s:17:"Olark Integration";s:11:"description";s:145:"Sign up for an Olark account and experience the easiest way to boost your sales, help solve issues, and understand your customers with live chat.";s:8:"logo_url";s:68:"//theme.co/media/x_extensions/200-200-no-title-olark-integration.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:52:"http://theme.co/x/demo/extensions/olark-integration/";}i:14;a:9:{s:4:"slug";s:15:"x-smooth-scroll";s:6:"plugin";s:35:"x-smooth-scroll/x-smooth-scroll.php";s:11:"new_version";s:5:"1.0.2";s:7:"package";N;s:5:"title";s:13:"Smooth Scroll";s:11:"description";s:179:"Enabling smooth scrolling on your website allows you to manage the physics of your scroll bar! This fun effect is great if you happen to have a lot users who utilize a mousewheel.";s:8:"logo_url";s:64:"//theme.co/media/x_extensions/200-200-no-title-smooth-scroll.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:48:"http://theme.co/x/demo/extensions/smooth-scroll/";}i:15;a:9:{s:4:"slug";s:14:"x-terms-of-use";s:6:"plugin";s:33:"x-terms-of-use/x-terms-of-use.php";s:11:"new_version";s:5:"1.0.0";s:7:"package";N;s:5:"title";s:12:"Terms of Use";s:11:"description";s:120:"This plugin will allow you to add a simple terms of use that visitors must agree to before completing user registration.";s:8:"logo_url";s:63:"//theme.co/media/x_extensions/200-200-no-title-terms-of-use.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:47:"http://theme.co/x/demo/extensions/terms-of-use/";}i:16;a:9:{s:4:"slug";s:9:"x-typekit";s:6:"plugin";s:23:"x-typekit/x-typekit.php";s:11:"new_version";s:5:"1.0.1";s:7:"package";N;s:5:"title";s:7:"Typekit";s:11:"description";s:145:"Create beautiful designs by incorporating Typekit fonts into your website. Our custom Extension makes this premium service easy to setup and use.";s:8:"logo_url";s:58:"//theme.co/media/x_extensions/200-200-no-title-typekit.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:42:"http://theme.co/x/demo/extensions/typekit/";}i:17;a:9:{s:4:"slug";s:20:"x-under-construction";s:6:"plugin";s:45:"x-under-construction/x-under-construction.php";s:11:"new_version";s:5:"1.1.1";s:7:"package";N;s:5:"title";s:18:"Under Construction";s:11:"description";s:172:"Got a little work that needs to be done under the hood? The Under Construction plugin is the easiest maintenance plugin you\'ll ever setup and the last one you\'ll ever need.";s:8:"logo_url";s:69:"//theme.co/media/x_extensions/200-200-no-title-under-construction.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:53:"http://theme.co/x/demo/extensions/under-construction/";}i:18;a:9:{s:4:"slug";s:12:"x-video-lock";s:6:"plugin";s:29:"x-video-lock/x-video-lock.php";s:11:"new_version";s:5:"1.1.1";s:7:"package";N;s:5:"title";s:10:"Video Lock";s:11:"description";s:138:"You\'ve never seen a video marketing tool quite like Video Lock. Place offers and a call to action in front of your users without any fuss.";s:8:"logo_url";s:61:"//theme.co/media/x_extensions/200-200-no-title-video-lock.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:45:"http://theme.co/x/demo/extensions/video-lock/";}i:19;a:9:{s:4:"slug";s:13:"x-white-label";s:6:"plugin";s:31:"x-white-label/x-white-label.php";s:11:"new_version";s:5:"1.1.0";s:7:"package";N;s:5:"title";s:11:"White Label";s:11:"description";s:200:"Customize the WordPress login screen, Addons home page, and much more. This is a great tool to use if handing X off to a client to provide them with tailored content right in the WordPress admin area.";s:8:"logo_url";s:62:"//theme.co/media/x_extensions/200-200-no-title-white-label.png";s:6:"author";s:7:"Themeco";s:8:"demo_url";s:46:"http://theme.co/x/demo/extensions/white-label/";}}', 'yes'),
(168, 'themeco_update_cache', 'a:2:{s:6:"themes";a:1:{s:1:"x";a:4:{s:5:"theme";s:1:"x";s:11:"new_version";s:5:"4.3.4";s:3:"url";s:18:"http://theme.co/x/";s:7:"package";N;}}s:7:"plugins";a:21:{s:27:"cornerstone/cornerstone.php";a:7:{s:4:"slug";s:11:"cornerstone";s:6:"plugin";s:27:"cornerstone/cornerstone.php";s:11:"new_version";s:5:"1.1.3";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:27:"convertplug/convertplug.php";a:7:{s:4:"slug";s:11:"convertplug";s:6:"plugin";s:27:"convertplug/convertplug.php";s:11:"new_version";s:5:"1.1.1";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:33:"envira-gallery/envira-gallery.php";a:7:{s:4:"slug";s:14:"envira-gallery";s:6:"plugin";s:33:"envira-gallery/envira-gallery.php";s:11:"new_version";s:7:"1.4.1.3";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:33:"essential-grid/essential-grid.php";a:7:{s:4:"slug";s:14:"essential-grid";s:6:"plugin";s:33:"essential-grid/essential-grid.php";s:11:"new_version";s:7:"2.0.9.1";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:27:"js_composer/js_composer.php";a:7:{s:4:"slug";s:11:"js_composer";s:6:"plugin";s:27:"js_composer/js_composer.php";s:11:"new_version";s:5:"4.9.2";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:27:"LayerSlider/layerslider.php";a:7:{s:4:"slug";s:11:"layerslider";s:6:"plugin";s:27:"LayerSlider/layerslider.php";s:11:"new_version";s:5:"5.6.2";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:23:"revslider/revslider.php";a:7:{s:4:"slug";s:9:"revslider";s:6:"plugin";s:23:"revslider/revslider.php";s:11:"new_version";s:5:"5.1.6";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:23:"soliloquy/soliloquy.php";a:7:{s:4:"slug";s:9:"soliloquy";s:6:"plugin";s:23:"soliloquy/soliloquy.php";s:11:"new_version";s:5:"2.4.3";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:33:"x-content-dock/x-content-dock.php";a:7:{s:4:"slug";s:14:"x-content-dock";s:6:"plugin";s:33:"x-content-dock/x-content-dock.php";s:11:"new_version";s:5:"1.0.0";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:29:"x-custom-404/x-custom-404.php";a:7:{s:4:"slug";s:12:"x-custom-404";s:6:"plugin";s:29:"x-custom-404/x-custom-404.php";s:11:"new_version";s:5:"1.1.0";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:39:"x-disqus-comments/x-disqus-comments.php";a:7:{s:4:"slug";s:17:"x-disqus-comments";s:6:"plugin";s:39:"x-disqus-comments/x-disqus-comments.php";s:11:"new_version";s:5:"1.0.0";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:39:"x-email-mailchimp/x-email-mailchimp.php";a:7:{s:4:"slug";s:17:"x-email-mailchimp";s:6:"plugin";s:39:"x-email-mailchimp/x-email-mailchimp.php";s:11:"new_version";s:5:"1.1.1";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:43:"x-facebook-comments/x-facebook-comments.php";a:7:{s:4:"slug";s:19:"x-facebook-comments";s:6:"plugin";s:43:"x-facebook-comments/x-facebook-comments.php";s:11:"new_version";s:5:"1.0.1";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:41:"x-google-analytics/x-google-analytics.php";a:7:{s:4:"slug";s:18:"x-google-analytics";s:6:"plugin";s:41:"x-google-analytics/x-google-analytics.php";s:11:"new_version";s:5:"1.0.0";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:43:"x-olark-integration/x-olark-integration.php";a:7:{s:4:"slug";s:19:"x-olark-integration";s:6:"plugin";s:43:"x-olark-integration/x-olark-integration.php";s:11:"new_version";s:5:"1.0.0";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:35:"x-smooth-scroll/x-smooth-scroll.php";a:7:{s:4:"slug";s:15:"x-smooth-scroll";s:6:"plugin";s:35:"x-smooth-scroll/x-smooth-scroll.php";s:11:"new_version";s:5:"1.0.2";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:33:"x-terms-of-use/x-terms-of-use.php";a:7:{s:4:"slug";s:14:"x-terms-of-use";s:6:"plugin";s:33:"x-terms-of-use/x-terms-of-use.php";s:11:"new_version";s:5:"1.0.0";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:23:"x-typekit/x-typekit.php";a:7:{s:4:"slug";s:9:"x-typekit";s:6:"plugin";s:23:"x-typekit/x-typekit.php";s:11:"new_version";s:5:"1.0.1";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:45:"x-under-construction/x-under-construction.php";a:7:{s:4:"slug";s:20:"x-under-construction";s:6:"plugin";s:45:"x-under-construction/x-under-construction.php";s:11:"new_version";s:5:"1.1.1";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:29:"x-video-lock/x-video-lock.php";a:7:{s:4:"slug";s:12:"x-video-lock";s:6:"plugin";s:29:"x-video-lock/x-video-lock.php";s:11:"new_version";s:5:"1.1.1";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}s:31:"x-white-label/x-white-label.php";a:7:{s:4:"slug";s:13:"x-white-label";s:6:"plugin";s:31:"x-white-label/x-white-label.php";s:11:"new_version";s:5:"1.1.0";s:3:"url";s:38:"http://theme.co/changelog/?iframe=true";s:7:"package";N;s:14:"upgrade_notice";s:16:"Update Available";s:6:"tested";s:5:"4.4.2";}}}', 'yes'),
(171, 'cornerstone_version', '1.1.1', 'yes'),
(174, 'rewrite_rules', 'a:150:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"portfolio-item/?$";s:31:"index.php?post_type=x-portfolio";s:47:"portfolio-item/feed/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=x-portfolio&feed=$matches[1]";s:42:"portfolio-item/(feed|rdf|rss|rss2|atom)/?$";s:48:"index.php?post_type=x-portfolio&feed=$matches[1]";s:34:"portfolio-item/page/([0-9]{1,})/?$";s:49:"index.php?post_type=x-portfolio&paged=$matches[1]";s:45:"cs_user_templates/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"cs_user_templates/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"cs_user_templates/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"cs_user_templates/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"cs_user_templates/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"cs_user_templates/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"cs_user_templates/([^/]+)/embed/?$";s:50:"index.php?cs_user_templates=$matches[1]&embed=true";s:38:"cs_user_templates/([^/]+)/trackback/?$";s:44:"index.php?cs_user_templates=$matches[1]&tb=1";s:46:"cs_user_templates/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?cs_user_templates=$matches[1]&paged=$matches[2]";s:53:"cs_user_templates/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?cs_user_templates=$matches[1]&cpage=$matches[2]";s:57:"cs_user_templates/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:72:"index.php?cs_user_templates=$matches[1]&cornerstone-endpoint=$matches[3]";s:63:"cs_user_templates/[^/]+/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:65:"index.php?attachment=$matches[1]&cornerstone-endpoint=$matches[3]";s:74:"cs_user_templates/[^/]+/attachment/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:65:"index.php?attachment=$matches[1]&cornerstone-endpoint=$matches[3]";s:42:"cs_user_templates/([^/]+)(?:/([0-9]+))?/?$";s:56:"index.php?cs_user_templates=$matches[1]&page=$matches[2]";s:34:"cs_user_templates/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"cs_user_templates/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"cs_user_templates/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"cs_user_templates/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"cs_user_templates/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"cs_user_templates/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:46:"category/(.+?)/cornerstone-endpoint(/(.*))?/?$";s:68:"index.php?category_name=$matches[1]&cornerstone-endpoint=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:43:"tag/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:58:"index.php?tag=$matches[1]&cornerstone-endpoint=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:42:"portfolio-item/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:52:"portfolio-item/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:72:"portfolio-item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:67:"portfolio-item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:67:"portfolio-item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:"portfolio-item/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:31:"portfolio-item/([^/]+)/embed/?$";s:44:"index.php?x-portfolio=$matches[1]&embed=true";s:35:"portfolio-item/([^/]+)/trackback/?$";s:38:"index.php?x-portfolio=$matches[1]&tb=1";s:55:"portfolio-item/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?x-portfolio=$matches[1]&feed=$matches[2]";s:50:"portfolio-item/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?x-portfolio=$matches[1]&feed=$matches[2]";s:43:"portfolio-item/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?x-portfolio=$matches[1]&paged=$matches[2]";s:50:"portfolio-item/([^/]+)/comment-page-([0-9]{1,})/?$";s:51:"index.php?x-portfolio=$matches[1]&cpage=$matches[2]";s:54:"portfolio-item/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:66:"index.php?x-portfolio=$matches[1]&cornerstone-endpoint=$matches[3]";s:60:"portfolio-item/[^/]+/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:65:"index.php?attachment=$matches[1]&cornerstone-endpoint=$matches[3]";s:71:"portfolio-item/[^/]+/attachment/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:65:"index.php?attachment=$matches[1]&cornerstone-endpoint=$matches[3]";s:39:"portfolio-item/([^/]+)(?:/([0-9]+))?/?$";s:50:"index.php?x-portfolio=$matches[1]&page=$matches[2]";s:31:"portfolio-item/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"portfolio-item/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"portfolio-item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"portfolio-item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"portfolio-item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"portfolio-item/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:59:"portfolio-item-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?portfolio-tag=$matches[1]&feed=$matches[2]";s:54:"portfolio-item-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?portfolio-tag=$matches[1]&feed=$matches[2]";s:47:"portfolio-item-tag/([^/]+)/page/?([0-9]{1,})/?$";s:53:"index.php?portfolio-tag=$matches[1]&paged=$matches[2]";s:29:"portfolio-item-tag/([^/]+)/?$";s:35:"index.php?portfolio-tag=$matches[1]";s:64:"portfolio-item-category/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:57:"index.php?portfolio-category=$matches[1]&feed=$matches[2]";s:59:"portfolio-item-category/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:57:"index.php?portfolio-category=$matches[1]&feed=$matches[2]";s:52:"portfolio-item-category/([^/]+)/page/?([0-9]{1,})/?$";s:58:"index.php?portfolio-category=$matches[1]&paged=$matches[2]";s:34:"portfolio-item-category/([^/]+)/?$";s:40:"index.php?portfolio-category=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:31:"cornerstone-endpoint(/(.*))?/?$";s:43:"index.php?&cornerstone-endpoint=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:40:"comments/cornerstone-endpoint(/(.*))?/?$";s:43:"index.php?&cornerstone-endpoint=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:43:"search/(.+)/cornerstone-endpoint(/(.*))?/?$";s:56:"index.php?s=$matches[1]&cornerstone-endpoint=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:46:"author/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:66:"index.php?author_name=$matches[1]&cornerstone-endpoint=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:68:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/cornerstone-endpoint(/(.*))?/?$";s:96:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cornerstone-endpoint=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:55:"([0-9]{4})/([0-9]{1,2})/cornerstone-endpoint(/(.*))?/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&cornerstone-endpoint=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:42:"([0-9]{4})/cornerstone-endpoint(/(.*))?/?$";s:59:"index.php?year=$matches[1]&cornerstone-endpoint=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:39:"(.?.+?)/cornerstone-endpoint(/(.*))?/?$";s:63:"index.php?pagename=$matches[1]&cornerstone-endpoint=$matches[3]";s:45:".?.+?/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:65:"index.php?attachment=$matches[1]&cornerstone-endpoint=$matches[3]";s:56:".?.+?/attachment/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:65:"index.php?attachment=$matches[1]&cornerstone-endpoint=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:31:".+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:".+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:".+?/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"(.+?)/([^/]+)/embed/?$";s:63:"index.php?category_name=$matches[1]&name=$matches[2]&embed=true";s:26:"(.+?)/([^/]+)/trackback/?$";s:57:"index.php?category_name=$matches[1]&name=$matches[2]&tb=1";s:46:"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:41:"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:34:"(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]";s:41:"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]";s:45:"(.+?)/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:85:"index.php?category_name=$matches[1]&name=$matches[2]&cornerstone-endpoint=$matches[4]";s:49:".+?/[^/]+/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:65:"index.php?attachment=$matches[1]&cornerstone-endpoint=$matches[3]";s:60:".+?/[^/]+/attachment/([^/]+)/cornerstone-endpoint(/(.*))?/?$";s:65:"index.php?attachment=$matches[1]&cornerstone-endpoint=$matches[3]";s:30:"(.+?)/([^/]+)(?:/([0-9]+))?/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]";s:20:".+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:".+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:".+?/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:38:"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:26:"(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:33:"(.+?)/comment-page-([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&cpage=$matches[2]";s:37:"(.+?)/cornerstone-endpoint(/(.*))?/?$";s:68:"index.php?category_name=$matches[1]&cornerstone-endpoint=$matches[3]";s:8:"(.+?)/?$";s:35:"index.php?category_name=$matches[1]";}', 'yes'),
(181, 'recently_activated', 'a:0:{}', 'yes'),
(184, 'limit_login_retries', 'a:1:{s:14:"141.163.219.24";i:2;}', 'no'),
(185, 'limit_login_retries_valid', 'a:1:{s:14:"141.163.219.24";i:1455143171;}', 'no'),
(189, 'x_cache_google_fonts_request', '//fonts.googleapis.com/css?family=Lato:400,400italic,700,700italic&subset=latin,latin-ext', 'yes') ;

#
# End of data contents of table `hkgj_options`
# --------------------------------------------------------



#
# Delete any existing table `hkgj_postmeta`
#

DROP TABLE IF EXISTS `hkgj_postmeta`;


#
# Table structure of table `hkgj_postmeta`
#

CREATE TABLE `hkgj_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;


#
# Data contents of table `hkgj_postmeta`
#
INSERT INTO `hkgj_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(4, 7, '_edit_lock', '1455102025:3'),
(5, 7, '_edit_last', '3'),
(7, 7, '_x_entry_body_css_class', ''),
(8, 7, '_x_post_layout', 'off'),
(9, 7, '_x_entry_alternate_index_title', ''),
(10, 7, '_x_entry_bg_image_full', ''),
(11, 7, '_x_entry_bg_image_full_fade', '750'),
(12, 7, '_x_entry_bg_image_full_duration', '7500'),
(13, 7, '_x_quote_quote', ''),
(14, 7, '_x_quote_cite', ''),
(15, 7, '_x_link_url', ''),
(16, 7, '_x_video_aspect_ratio', '16:9'),
(17, 7, '_x_video_m4v', ''),
(18, 7, '_x_video_ogv', ''),
(19, 7, '_x_video_embed', ''),
(20, 7, '_x_audio_mp3', ''),
(21, 7, '_x_audio_ogg', ''),
(22, 7, '_x_audio_embed', ''),
(23, 8, '_cornerstone_data', ''),
(24, 8, '_cornerstone_override', ''),
(25, 8, '_cornerstone_settings', '') ;

#
# End of data contents of table `hkgj_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `hkgj_posts`
#

DROP TABLE IF EXISTS `hkgj_posts`;


#
# Table structure of table `hkgj_posts`
#

CREATE TABLE `hkgj_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;


#
# Data contents of table `hkgj_posts`
#
INSERT INTO `hkgj_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-02-10 09:33:21', '2016-02-10 09:33:21', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2016-02-10 09:33:21', '2016-02-10 09:33:21', '', 0, 'http://192.168.33.10//?p=1', 0, 'post', '', 1),
(2, 1, '2016-02-10 09:33:21', '2016-02-10 09:33:21', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2016-02-10 09:33:21', '2016-02-10 09:33:21', '', 0, 'http://192.168.33.10//?page_id=2', 0, 'page', '', 0),
(3, 1, '2016-02-10 10:14:19', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-02-10 10:14:19', '0000-00-00 00:00:00', '', 0, 'http://192.168.33.10//?p=3', 0, 'post', '', 0),
(5, 3, '2016-02-10 10:31:37', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-02-10 10:31:37', '0000-00-00 00:00:00', '', 0, 'http://192.168.33.10//?p=5', 0, 'post', '', 0),
(6, 2, '2016-02-10 10:31:55', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-02-10 10:31:55', '0000-00-00 00:00:00', '', 0, 'http://192.168.33.10//?p=6', 0, 'post', '', 0),
(7, 3, '2016-02-10 11:02:36', '2016-02-10 11:02:36', 'bxqjkwb;qbqwlwqlqwxnlkwnxklqwxjwqnjkwnjwqnxjwqnxjwqnkjwqnkjwnq', 'Test post', '', 'publish', 'open', 'open', '', 'test-post', '', '', '2016-02-10 11:02:36', '2016-02-10 11:02:36', '', 0, 'http://192.168.33.10//?p=7', 0, 'post', '', 0),
(8, 3, '2016-02-10 11:02:36', '2016-02-10 11:02:36', 'bxqjkwb;qbqwlwqlqwxnlkwnxklqwxjwqnjkwnjwqnxjwqnxjwqnkjwqnkjwnq', 'Test post', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2016-02-10 11:02:36', '2016-02-10 11:02:36', '', 7, 'http://192.168.33.10//uncategorized/7-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `hkgj_posts`
# --------------------------------------------------------



#
# Delete any existing table `hkgj_term_relationships`
#

DROP TABLE IF EXISTS `hkgj_term_relationships`;


#
# Table structure of table `hkgj_term_relationships`
#

CREATE TABLE `hkgj_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `hkgj_term_relationships`
#
INSERT INTO `hkgj_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 2, 0),
(2, 2, 0),
(3, 2, 0),
(4, 2, 0),
(5, 2, 0),
(6, 2, 0),
(7, 1, 0),
(7, 2, 0) ;

#
# End of data contents of table `hkgj_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `hkgj_term_taxonomy`
#

DROP TABLE IF EXISTS `hkgj_term_taxonomy`;


#
# Table structure of table `hkgj_term_taxonomy`
#

CREATE TABLE `hkgj_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


#
# Data contents of table `hkgj_term_taxonomy`
#
INSERT INTO `hkgj_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'link_category', '', 0, 7) ;

#
# End of data contents of table `hkgj_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `hkgj_termmeta`
#

DROP TABLE IF EXISTS `hkgj_termmeta`;


#
# Table structure of table `hkgj_termmeta`
#

CREATE TABLE `hkgj_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `hkgj_termmeta`
#

#
# End of data contents of table `hkgj_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `hkgj_terms`
#

DROP TABLE IF EXISTS `hkgj_terms`;


#
# Table structure of table `hkgj_terms`
#

CREATE TABLE `hkgj_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;


#
# Data contents of table `hkgj_terms`
#
INSERT INTO `hkgj_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Blogroll', 'blogroll', 0) ;

#
# End of data contents of table `hkgj_terms`
# --------------------------------------------------------



#
# Delete any existing table `hkgj_usermeta`
#

DROP TABLE IF EXISTS `hkgj_usermeta`;


#
# Table structure of table `hkgj_usermeta`
#

CREATE TABLE `hkgj_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;


#
# Data contents of table `hkgj_usermeta`
#
INSERT INTO `hkgj_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'first_name', ''),
(2, 1, 'last_name', ''),
(3, 1, 'nickname', 'admin'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'aim', ''),
(10, 1, 'yim', ''),
(11, 1, 'jabber', ''),
(12, 1, 'hkgj_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}'),
(13, 1, 'hkgj_user_level', '10'),
(15, 1, 'hkgj_dashboard_quick_press_last_post_id', '3'),
(16, 1, 'wporg_favorites', ''),
(17, 2, 'nickname', 'darren'),
(18, 2, 'first_name', 'Darren'),
(19, 2, 'last_name', 'Shilson'),
(20, 2, 'description', ''),
(21, 2, 'rich_editing', 'true'),
(22, 2, 'comment_shortcuts', 'false'),
(23, 2, 'admin_color', 'fresh'),
(24, 2, 'use_ssl', '0'),
(25, 2, 'show_admin_bar_front', 'true'),
(26, 2, 'hkgj_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(27, 2, 'hkgj_user_level', '10'),
(28, 2, 'dismissed_wp_pointers', ''),
(29, 3, 'nickname', 'Aaron'),
(30, 3, 'first_name', 'Aaron'),
(31, 3, 'last_name', 'Coward'),
(32, 3, 'description', ''),
(33, 3, 'rich_editing', 'true'),
(34, 3, 'comment_shortcuts', 'false'),
(35, 3, 'admin_color', 'blue'),
(36, 3, 'use_ssl', '0'),
(37, 3, 'show_admin_bar_front', 'true'),
(38, 3, 'hkgj_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(39, 3, 'hkgj_user_level', '10'),
(40, 3, 'dismissed_wp_pointers', ''),
(41, 3, 'session_tokens', 'a:2:{s:64:"74174df74452726fffba97a26de7eebb64f87e245cde40e82f535d1bc92489cc";a:4:{s:10:"expiration";i:1455272807;s:2:"ip";s:14:"141.163.219.24";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.103 Safari/537.36";s:5:"login";i:1455100007;}s:64:"831d857646c34106ef565f2d1be725c36c17c880e2dfb7f7f2b0cad85d584c17";a:4:{s:10:"expiration";i:1456309893;s:2:"ip";s:14:"141.163.219.24";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.103 Safari/537.36";s:5:"login";i:1455100293;}}'),
(42, 3, 'hkgj_dashboard_quick_press_last_post_id', '5'),
(43, 2, 'session_tokens', 'a:1:{s:64:"bf8b9bbf3cebc7a700c1d7a4977f095c9ccb82d5bbd248a39957cda8b7099dc1";a:4:{s:10:"expiration";i:1455273111;s:2:"ip";s:14:"141.163.219.24";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.103 Safari/537.36";s:5:"login";i:1455100311;}}'),
(44, 2, 'hkgj_dashboard_quick_press_last_post_id', '6') ;

#
# End of data contents of table `hkgj_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `hkgj_users`
#

DROP TABLE IF EXISTS `hkgj_users`;


#
# Table structure of table `hkgj_users`
#

CREATE TABLE `hkgj_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


#
# Data contents of table `hkgj_users`
#
INSERT INTO `hkgj_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'y3qsfp', '$P$BsB0BK0rQ6KcUBEyhGcP.HKOFIBdBR.', 'admin', 'admin@cios.website', '', '2016-02-10 09:33:21', '', 0, 'admin'),
(2, 'darren', '$P$BV3a5VX9llz7gwzOAZbyFuhTPR1blz1', 'darren', 'darren@ciosgrowthhub.com', '', '2016-02-10 10:23:06', '1455099786:$P$BD/cePo1q9ijrgtndXUd6sX0B1q6.X0', 0, 'Darren Shilson'),
(3, 'Aaron', '$P$BSwYHLQjI4PoHW.y6kz3LljV5LSkq//', 'aaron', 'aaron@ciosgrowthhub.com', '', '2016-02-10 10:23:53', '1455099834:$P$BQ8zFO0phM/YuVNryD7a8r1RSsZqNR/', 0, 'Aaron Coward') ;

#
# End of data contents of table `hkgj_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

